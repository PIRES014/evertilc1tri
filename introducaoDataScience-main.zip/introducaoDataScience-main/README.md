# introducaoDataScience
Arquivos necessários para as aulas iniciais de Introdução a Ciências de Dados
